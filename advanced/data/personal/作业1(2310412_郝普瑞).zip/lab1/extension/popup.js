document.getElementById('apply').addEventListener('click', async () => {
  const color = document.getElementById('color').value;
  // 在当前活动标签页注入脚本以设置背景色
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabs || !tabs[0]) return;
  chrome.scripting.executeScript({
    target: { tabId: tabs[0].id },
    func: (bg) => { document.body.style.background = bg; },
    args: [color]
  });
});
