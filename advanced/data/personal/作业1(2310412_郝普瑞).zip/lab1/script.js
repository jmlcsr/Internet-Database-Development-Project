function logNetwork(msg) {
  const el = document.getElementById('networkLog');
  const p = document.createElement('div');
  p.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
  el.prepend(p);
  console.log(msg);
}

// Fetch GET
document.getElementById('btnFetchGet').addEventListener('click', async () => {
  logNetwork('Fetch GET -> https://jsonplaceholder.typicode.com/posts/1');
  const res = await fetch('https://jsonplaceholder.typicode.com/posts/1');
  const data = await res.json();
  logNetwork('Fetch GET 响应: ' + JSON.stringify(data));
});

// Fetch POST
document.getElementById('btnFetchPost').addEventListener('click', async () => {
  const payload = { title: '测试', body: '这是通过fetch发送的POST', userId: 1 };
  logNetwork('Fetch POST -> https://jsonplaceholder.typicode.com/posts  payload: ' + JSON.stringify(payload));
  const res = await fetch('https://jsonplaceholder.typicode.com/posts', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
  });
  const data = await res.json();
  logNetwork('Fetch POST 响应: ' + JSON.stringify(data));
});

// jQuery GET / POST
document.getElementById('btnJqGet').addEventListener('click', () => {
  logNetwork('jQuery GET -> https://jsonplaceholder.typicode.com/posts/1');
  $.get('https://jsonplaceholder.typicode.com/posts/1', function(data){
    logNetwork('jQuery GET 响应: ' + JSON.stringify(data));
  });
});

document.getElementById('btnJqPost').addEventListener('click', () => {
  const payload = { title: '测试_jq', body: '这是通过jQuery发送的POST', userId: 2 };
  logNetwork('jQuery POST -> https://jsonplaceholder.typicode.com/posts  payload: ' + JSON.stringify(payload));
  $.post('https://jsonplaceholder.typicode.com/posts', payload, function(data){
    logNetwork('jQuery POST 响应: ' + JSON.stringify(data));
  });
});

// jQuery event with at least three statements
$('#btnAction').on('click', function(){
  // 1) 修改按钮文本
  $(this).text('已点击');
  // 2) 修改页面背景色
  $('body').css('background-color', '#fff9e6');
  // 3) 在结果区域追加内容
  $('#result').append('<div>事件已触发：' + new Date().toLocaleTimeString() + '</div>');
  // 额外语句：记录 console
  console.log('jQuery event executed: changed text, background, appended content');
});
