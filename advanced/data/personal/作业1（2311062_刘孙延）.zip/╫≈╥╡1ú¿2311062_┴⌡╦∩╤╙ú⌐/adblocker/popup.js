// 点击按钮时，向当前标签页的content.js发送“隐藏广告”消息
document.getElementById("hide-btn").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: "hideAds" });
  });
});