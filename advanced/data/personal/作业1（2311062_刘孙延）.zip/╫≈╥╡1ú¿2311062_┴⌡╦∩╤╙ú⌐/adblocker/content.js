// ========== 步骤1：定义广告特征选择器 ==========
// 可扩展：根据常见广告的类名/ID，添加更多选择器
const adSelectors = [
  'div[class*="ad"]',    // 类名含"ad"的div（如class="ad-banner"）
  'div[id*="ad"]',       // ID含"ad"的div（如id="ad-container"）
  'section[class*="advertisement"]', // 类名含"advertisement"的section
  'span[class*="ad"]',   // 类名含"ad"的span
  '.banner', '.ads',     // 常见广告类名（如class="banner"）
  '#ad', '#ads'          // 常见广告ID（如id="ad"）
];

// ========== 步骤2：隐藏广告的函数 ==========
function hideAds() {
  adSelectors.forEach(selector => {
    // 遍历所有匹配的元素，设置display: none
    document.querySelectorAll(selector).forEach(ad => {
      ad.style.display = "none";
    });
  });
  console.log("广告隐藏完成！"); // 控制台提示（可选）
}

// ========== 步骤3：自动隐藏（页面加载完成后执行） ==========
// 页面DOM加载完成后，自动调用hideAds
document.addEventListener('DOMContentLoaded', hideAds);

// ========== 步骤4：接收popup的手动触发消息（可选） ==========
// 如果需要通过popup按钮“手动隐藏广告”，需添加消息监听
chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "hideAds") {
    hideAds(); // 收到消息后执行隐藏逻辑
  }
});